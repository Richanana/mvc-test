<h1> SIGN UP</h1>
<input type="text" id="name" placeholder="Name">
<input type="password" id="pass1" placeholder="Password">
<input type="submit" id="submit" value="Sign Up">