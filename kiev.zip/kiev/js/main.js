$(document).ready(function(){




    $('#submit').click(function(){




        var name = $('#name').val();
        var mail = $('#mail').val();
        var pass1 = $('#pass1').val();
        var pass2 = $('#pass2').val();
        var submit =$(this).val();

        var reMail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        var reNameAndPass = /^\w{5,50}/;
        

        $.ajax({
            url:'./validation.php',
            type:'post',
            data:{name:name,mail:mail,pass1:pass1,pass2:pass2,submit:submit},
            error:function(e){
                document.write(e)
            },
            success:function(e){
                document.write(e);
                // $('div').innerHTML= e;
            }
        });
    });
});
function validateEmail(email) {
    var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return re.test(String(email).toLowerCase());
}