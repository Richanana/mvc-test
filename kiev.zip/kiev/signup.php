<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="js/main.js"></script>

<h1> SIGN UP</h1>
<input type="text" id="name" placeholder="Name">
<input type="email" id="mail" placeholder="Email">
<input type="password" id="pass1" placeholder="Password">
<input type="password" id="pass2" placeholder="Repeat Password">
<input type="submit" id="submit" value="Sign Up">






