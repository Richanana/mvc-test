<?php
$name= filter_var(trim($_POST['name']),FILTER_SANITIZE_STRING);
$mail= filter_var(trim($_POST['mail']),FILTER_SANITIZE_STRING);
$pass1= filter_var(trim($_POST['pass1']),FILTER_SANITIZE_STRING);
$pass2= filter_var(trim($_POST['pass2']),FILTER_SANITIZE_STRING);
$submit= filter_var(trim($_POST['submit']),FILTER_SANITIZE_STRING);


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kiev";

$conn = new mysqli($servername, $username, $password, $dbname);
$conn->query("INSERT INTO `signup` (Name, Email, Password) VALUES('$name','$mail',MD5('$pass1'))");
$conn->close();
echo 'norm';